# 宿主 shell 的代理端口陷阱（WorkBuddy）

> 配套技能：`must-read-for-penetration-testing`（必读）。本节描述的是**宿主工具链特性**，与靶场出口无关。

## 1. 现象：端口每会话都变

shell 里存在 `http_proxy` / `https_proxy` / `HTTP_PROXY` / `HTTPS_PROXY`，值形如：

```
http_proxy=http://127.0.0.1:<高位随机端口>
```

**每次新会话端口都不一样**（实测先后遇到 `9215`、`13199`、`8525`）。

## 2. 判据：先查端口属主，再下结论

```bash
netstat -ano | grep ":<端口>"        # 取到 PID
```

```python
import psutil
psutil.Process(<PID>).name()          # → sandbox-cli.exe
```

属主是 `sandbox-cli.exe`（或 IDE / 沙箱类进程）时，说明这是**宿主环境注入的**。

**不是**本机代理软件留下的痕迹：Clash / Mihomo / v2ray 这类 GUI 客户端走系统代理（WinINET，写注册表），**不设置环境变量**。把它当成「代理泄漏」是常见误判 —— **别写死端口，也别去"清理"它**。

## 3. 它是干什么用的：什么都不是

**它不是出口。** 靶场的唯一出口是本机端口转发那条通路（见 `unique-egress.md`）。
不得借这个变量把流量送出外网 —— 那正是红线 §2 一.3 禁止的「另开通道直连」。发现它的正确反应是**记录并绕开它对判据的干扰**，而不是利用它。

## 4. 唯一的实际危害：测本机端口时请求被劫走

`curl` / `wget` 默认读取这些变量，于是：

```bash
curl https://127.0.0.1:8443/     # 实际变成「让代理去连公网 8443」→ 超时
```

现象是「通路像是坏了」，其实只是测法错了 —— 而靶场入口恰恰全是 `127.0.0.1`，所以这条**必然**会踩。

## 5. 正确做法

- **curl**：加 `--noproxy '*'`。只写 `--noproxy 127.0.0.1` 不够 —— 代理地址本身是本地时更要显式。
- **脚本**：优先用 Python `socket` / `ssl` **直连**，不受代理变量影响，是更可靠的判据。
  注意 `urllib.request` / `requests` **仍会读** `http_proxy` / `https_proxy`（同样会被劫持），
  要真正绕开就用 `http.client.HTTPSConnection` + `ssl._create_unverified_context()`（自签证书场景）。
- 确实需要走代理时：用 `--proxy` 显式指定，不要依赖环境变量。
- 需要核对细节时看配套技能 `clashmi-local-port-forward` 的 §五（那里给出的正是本机端口验证的写法与判读）。

## 6. 排查顺序

1. 确认端口属主；
2. 确认是谁注入的；
3. **最后**才怀疑代理软件本身。

顺序颠倒的典型后果：把宿主注入的变量当成"环境被人动过"，进而去改配置 —— 直接触犯红线 §2 一.2。
