#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Host 改写反向代理（配 ClashMi tunnels 用）
=========================================

为什么需要它
------------
ClashMi 的 `tunnels` 是 **L4**（TCP）转发：只换目标 IP:端口，**不动 HTTP 的 Host 头**。
而目标 nginx 常按 `server_name` 分虚拟主机 —— 于是：

    浏览器访问 http://127.0.0.1:8443/   -> 发出 Host: 127.0.0.1:8443 -> 可能落到另一个 vhost
    直连      http://38.76.201.244/     -> 发出 Host: 38.76.201.244  -> 才是目标 vhost

本脚本在 tunnel 前面挡一层，把 Host 强行改写成你要的那个值，其余请求原样透传。
链路：客户端 -> 本脚本 -> ClashMi tunnel(127.0.0.1:8443) -> 目标 IP:80

用法
----
python host-rewrite-proxy.py --listen 127.0.0.1:8080 --upstream 127.0.0.1:8443 \
       --host-header 38.76.201.244

然后访问 http://127.0.0.1:8080/ 即等价于直连 http://38.76.201.244/
"""

import argparse
import socket
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# 逐跳头（RFC 7230 §6.1），透传时必须去掉/重算，否则会污染上游连接
HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-connection", "proxy-authenticate",
    "proxy-authorization", "te", "trailer", "trailers",
    "transfer-encoding", "upgrade",
}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "host-rewrite-proxy/1.0"

    # 静默默认日志，只在出错时说话
    def log_message(self, fmt, *args):
        if getattr(self.server, "verbose", False):
            sys.stderr.write("[proxy] %s - %s\n" % (self.address_string(), fmt % args))

    def _relay(self):
        srv = self.server

        # 1) 读客户端 body（按 Content-Length；无则视为无 body）
        body = b""
        cl = self.headers.get("Content-Length")
        if cl:
            try:
                body = self.rfile.read(int(cl))
            except Exception:
                body = b""

        # 2) 重组成上游请求：请求行原样，Host 强制替换，逐跳头剔除
        out = ["%s %s HTTP/1.1" % (self.command, self.path),
               "Host: %s" % srv.host_header]
        for k, v in self.headers.items():
            lk = k.lower()
            if lk == "host" or lk in HOP_BY_HOP:
                continue
            out.append("%s: %s" % (k, v))
        out.append("Connection: close")          # 上游一问一答，读到 EOF 即结束
        raw = ("\r\n".join(out) + "\r\n\r\n").encode("latin-1", "replace") + body

        # 3) 连上游并透传响应字节（状态行/头/体一律原样，包括 chunked）
        try:
            up = socket.create_connection(srv.upstream, timeout=srv.timeout)
        except OSError as e:
            msg = "upstream %s:%d 连不上: %s" % (srv.upstream[0], srv.upstream[1], e)
            payload = msg.encode("utf-8")
            self.wfile.write(b"HTTP/1.1 502 Bad Gateway\r\n"
                             b"Content-Type: text/plain; charset=utf-8\r\n"
                             b"Connection: close\r\n"
                             b"Content-Length: " + str(len(payload)).encode() + b"\r\n\r\n" + payload)
            self.close_connection = True
            return

        try:
            up.sendall(raw)
            while True:
                chunk = up.recv(16384)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
        except (OSError, BrokenPipeError):
            pass            # 客户端提前断开，属正常
        finally:
            try:
                up.close()
            except Exception:
                pass
            self.close_connection = True

    do_GET = do_POST = do_HEAD = do_PUT = do_DELETE = do_OPTIONS = do_PATCH = _relay


def parse_hostport(s, default_port):
    if ":" in s:
        h, p = s.rsplit(":", 1)
        return (h, int(p))
    return (s, default_port)


def main():
    ap = argparse.ArgumentParser(description="把 Host 头改写后转发给 ClashMi tunnel")
    ap.add_argument("--listen", default="127.0.0.1:8080", help="本机监听 host:port")
    ap.add_argument("--upstream", default="127.0.0.1:8443", help="ClashMi tunnel 的 host:port")
    ap.add_argument("--host-header", required=True, help="要强制发出的 Host（如 38.76.201.244）")
    ap.add_argument("--timeout", type=float, default=20.0, help="上游连接/读取超时秒")
    ap.add_argument("--verbose", action="store_true", help="打印每条请求")
    a = ap.parse_args()

    srv = ThreadingHTTPServer(parse_hostport(a.listen, 80), Handler)
    srv.daemon_threads = True
    srv.upstream = parse_hostport(a.upstream, 80)
    srv.host_header = a.host_header
    srv.timeout = a.timeout
    srv.verbose = a.verbose

    print("监听 http://%s:%d/  ->  tunnel %s:%d  (Host: %s)" % (
        srv.server_address[0], srv.server_address[1],
        srv.upstream[0], srv.upstream[1], srv.host_header), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。", flush=True)


if __name__ == "__main__":
    main()
