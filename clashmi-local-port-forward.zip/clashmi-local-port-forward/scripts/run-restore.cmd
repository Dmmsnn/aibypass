@echo off
setlocal
chcp 65001 >nul
title ClashMi tunnels - restore

rem 优先用带 psutil + PyYAML 的隔离环境，其次裸 Python
set "PY=C:\Users\Administrator\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" "%~dp0restore-tunnel.py" %*
set "RC=%ERRORLEVEL%"

echo.
echo ---------------------------------------------------------------
if "%RC%"=="0" (
  echo Restore finished.
) else (
  echo Restore stopped. Exit code %RC%  - see message above.
)
echo Tip: use  "run-restore.cmd --list"     to only list backups.
echo Tip: use  "run-restore.cmd --latest"   to restore newest, no prompt.
echo Tip: run as Administrator if Windows hosts is involved.
echo ---------------------------------------------------------------
pause
endlocal
