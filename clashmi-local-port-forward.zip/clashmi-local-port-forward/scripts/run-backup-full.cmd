@echo off
setlocal
chcp 65001 >nul
title ClashMi config - full backup

rem 优先用带 psutil + PyYAML 的隔离环境，其次裸 Python
set "PY=C:\Users\Administrator\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" "%~dp0backup-full.py" %*
set "RC=%ERRORLEVEL%"

echo.
echo ---------------------------------------------------------------
if "%RC%"=="0" (
  echo Full backup done. Exit code 0.
) else (
  echo Backup stopped. Exit code %RC%  - see message above.
)
echo ---------------------------------------------------------------
pause
endlocal
