@echo off
setlocal
chcp 65001 >nul
title ClashMi tunnels - verify

rem 优先用带 psutil + PyYAML 的隔离环境，其次裸 Python
set "PY=C:\Users\Administrator\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" "%~dp0verify-tunnel.py" %*
set "RC=%ERRORLEVEL%"

echo.
echo ---------------------------------------------------------------
if "%RC%"=="0" (
  echo Verify result: PASS  - tunnels is working.
) else (
  echo Verify result: NOT fully working. Exit code %RC%
)
echo This script is read-only. It changes nothing.
echo ---------------------------------------------------------------
pause
endlocal
