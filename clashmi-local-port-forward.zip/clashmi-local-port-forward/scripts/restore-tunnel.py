#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClashMi tunnels 一键还原脚本
============================

作用
----
把 apply-tunnel.py 改动过的文件，从 backups/<时间戳>/ 原样还原回去。

流程
----
1. 列出 backups/ 下所有备份（按时间倒序）
2. 让你选择还原哪一个（默认最新）
3. 先对「当前状态」再做一次快照（backups/pre-restore-<时间戳>/），
   所以还原本身也是可逆的
4. 校验备份文件 SHA256（与 manifest 记录比对）后原样写回
5. hosts 只有在 manifest 里记录过被修改时才会一起还原

用法
----
双击 run-restore.cmd，或运行本文件。
加参数 --list 只列备份不还原。
加参数 --latest 直接还原最新的一份，不询问。

多实例提示
----------
本机可能同时存在两套 ClashMi 安装（例如 %APPDATA%\\clashmi 与
C:\\Program Files\\ClashMi\\portable）。此时 --latest 只看时间戳，
有可能把**另一个实例**的备份还原上去，等于白改。
这种场景请改用：
  --backup <时间戳>   精确还原指定的一份（时间戳见 --list 输出）
  --for <路径子串>    只挑出涉及该文件的备份，如 --for Roaming\\clashmi

说明：全量目录快照（manual-full-*, 由 backup-full.py 产出）只做展示，
本脚本不会去还原它，避免按相对路径误覆盖。
"""

import ctypes
import hashlib
import json
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP_ROOT = os.path.join(HERE, "backups")


def say(msg=""):
    print(msg, flush=True)


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def decode_keep_bytes(path):
    with open(path, "rb") as f:
        raw = f.read()
    had_bom = raw.startswith(b"\xef\xbb\xbf")
    if had_bom:
        raw = raw[3:]
    try:
        text = raw.decode("utf-8")
        encoding = "utf-8"
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="surrogateescape")
        encoding = "cp1252-surrogateescape"
    return text, encoding, had_bom


def list_backups():
    if not os.path.isdir(BACKUP_ROOT):
        return []
    items = []
    for name in os.listdir(BACKUP_ROOT):
        d = os.path.join(BACKUP_ROOT, name)
        mf = os.path.join(d, "manifest.json")
        if os.path.isdir(d) and os.path.isfile(mf):
            try:
                with open(mf, "r", encoding="utf-8") as f:
                    manifest = json.load(f)
            except Exception:
                continue
            items.append((name, d, manifest))
    # pre-restore 快照排在普通备份之后，但仍按时间倒序整体列出
    items.sort(key=lambda x: x[0], reverse=True)
    return items


def is_full_snapshot(manifest):
    """backup-full.py 产出的目录级快照 vs apply-tunnel.py 的单文件备份。"""
    files = manifest.get("files", [])
    if manifest.get("source_dir") and not any(f.get("original") for f in files):
        return True
    return False


def display_path(mf, f):
    """兼容两种 manifest：单文件备份用 original 绝对路径；
    全量快照用 rel 相对路径（相对 source_dir）。"""
    if f.get("original"):
        return f["original"]
    rel = f.get("rel")
    if rel:
        return os.path.join(mf.get("source_dir", "<根目录>"), rel)
    return "?"


def digest_of(f):
    return (f.get("sha256_before") or f.get("sha256") or "?")


def show(items):
    say("可用备份（新 -> 旧）:")
    say()
    for i, (name, d, mf) in enumerate(items, 1):
        if name.startswith("pre-restore-"):
            kind = "还原前快照"
        elif is_full_snapshot(mf):
            kind = "全量目录快照"
        else:
            kind = "改动前备份"
        say("  {:>2}. {}   [{}]".format(i, name, kind))
        say("      说明: {}".format(mf.get("note", "")))
        for f in mf.get("files", []):
            say("      - {}  ({} 字节, sha256={}...)".format(
                display_path(mf, f), f.get("size", "?"), digest_of(f)[:12]))
        say()


def verify_and_restore(backup_dir, manifest, force=False):
    # 全量目录快照不能被当成"单文件改动备份"还原，否则会覆盖错东西
    if is_full_snapshot(manifest):
        say()
        say("[X] 这是一份「全量目录快照」（manual-full-*），不是单文件改动备份。")
        say("    它的 files[].rel 相对于:")
        say("      {}".format(manifest.get("source_dir")))
        say("    本脚本只还原带 original 绝对路径的单文件备份，避免误覆盖。")
        say("    要还原目录级快照，请手工从下面这份快照里整体复制回去:")
        say("      {}".format(backup_dir))
        return 1

    problems = []
    plan = []
    for f in manifest.get("files", []):
        src = os.path.join(backup_dir, f["backup"])
        if not os.path.isfile(src):
            problems.append("备份文件缺失: {}".format(src))
            continue
        digest = sha256_of(src)
        if f.get("sha256_before") and digest != f["sha256_before"]:
            problems.append("备份文件校验失败: {}（备份被改过？）".format(src))
            continue
        plan.append((src, f["original"]))

    if problems:
        say()
        for p in problems:
            say("[X] {}".format(p))
        if not force:
            say()
            say("存在校验问题，已中止。如确认要强行还原，请加 --force。")
            return 1

    if not plan:
        say("没有可还原的文件。")
        return 1

    say()
    say("将还原以下文件:")
    for src, dst in plan:
        exists = os.path.isfile(dst)
        say("  {} -> {}".format(os.path.basename(src), dst))
        if exists:
            say("     当前 sha256={}...  （会被覆盖）".format(sha256_of(dst)[:12]))
        else:
            say("     目标当前不存在，将新建")
    return plan


def main():
    args = sys.argv[1:]
    only_list = "--list" in args
    use_latest = "--latest" in args
    force = "--force" in args

    # 多实例精确选择：--backup <时间戳> / --for <路径子串>
    pick = None
    for_file = None
    for i, a in enumerate(args):
        if i + 1 < len(args) and a == "--backup":
            pick = args[i + 1]
        if i + 1 < len(args) and a == "--for":
            for_file = args[i + 1]
    noninteractive = use_latest or bool(pick)

    say("=" * 68)
    say(" ClashMi tunnels 一键还原")
    say("=" * 68)
    say()

    items = list_backups()
    if not items:
        say("[X] 没找到任何备份。")
        say("    备份目录: {}".format(BACKUP_ROOT))
        say("    如果你还没运行过 apply-tunnel.py，那本来就没有东西需要还原。")
        return 3

    if for_file:
        key = for_file.lower()
        items = [it for it in items
                 if any(key in f.get("original", "").lower()
                        for f in it[2].get("files", []))
                 or key in (it[2].get("source_dir", "") or "").lower()
                 or key in (it[2].get("core_path", "") or "").lower()]
        if not items:
            say("[X] 没有涉及 '{}' 的备份。".format(for_file))
            say("    先跑一次 --list 看看备份里到底涉及哪些文件。")
            return 4
        say("按 --for '{}' 过滤后剩 {} 份备份。".format(for_file, len(items)))
        say()

    show(items)
    if only_list:
        return 0

    if pick:
        match = [it for it in items if it[0] == pick]
        if not match:
            say("[X] 没找到备份: {}".format(pick))
            say("    可选: " + ", ".join(n for n, _, _ in items))
            return 4
        selected = match[0]
        say("按 --backup 精确选择: {}".format(selected[0]))
    elif use_latest:
        selected = items[0]
        say("按 --latest 选择最新备份: {}".format(selected[0]))
        say("[!] 注意：--latest 只看时间戳。本次将还原上面的文件，")
        say("    确认它们是你要动的那个实例，否则请改用 --backup <时间戳>。")
    else:
        try:
            raw = input("选择要还原的编号 [1]: ").strip()
        except EOFError:
            raw = ""
        if not raw:
            idx = 1
        elif raw.isdigit() and 1 <= int(raw) <= len(items):
            idx = int(raw)
        else:
            say("[X] 编号无效。")
            return 4
        selected = items[idx - 1]

    name, bdir, manifest = selected
    say()
    say("已选择: {}".format(name))

    # 还原前先给当前状态拍一张快照（只针对单文件备份；全量快照不参与）
    snapshot_files = []
    if not is_full_snapshot(manifest):
        for f in manifest.get("files", []):
            orig = f.get("original")
            if orig and os.path.isfile(orig):
                snapshot_files.append(orig)
    if snapshot_files:
        stamp = "pre-restore-" + time.strftime("%Y%m%d-%H%M%S")
        sdir = os.path.join(BACKUP_ROOT, stamp)
        os.makedirs(sdir, exist_ok=True)
        smf = {"time": stamp, "note": "还原 {0} 之前的当前状态".format(name), "files": []}
        for src in snapshot_files:
            try:
                dst = os.path.join(sdir, src.replace(":", "").replace("\\", "__").replace("/", "__"))
                shutil.copy2(src, dst)
                smf["files"].append({
                    "original": src,
                    "backup": os.path.basename(dst),
                    "sha256_before": sha256_of(src),
                    "size": os.path.getsize(src),
                })
            except Exception as e:
                say("[!] 快照 {} 失败: {}".format(src, e))
        with open(os.path.join(sdir, "manifest.json"), "w", encoding="utf-8") as f:
            json.dump(smf, f, ensure_ascii=False, indent=2)
        say("[OK] 已对当前状态拍快照: backups/{}".format(stamp))

    needs_admin = any(
        "drivers" in (f.get("original", "") or "").lower()
        and "etc" in (f.get("original", "") or "").lower()
        for f in manifest.get("files", [])
    )
    if needs_admin and not is_admin():
        say()
        say("[X] 这次还原包含 Windows hosts 文件，需要管理员权限。")
        say("    请用「以管理员身份运行」重新执行。")
        return 5

    plan = verify_and_restore(bdir, manifest, force=force)
    if not isinstance(plan, list):
        return plan

    if not noninteractive:
        say()
        try:
            raw = input("确认还原 [y/N]: ").strip().lower()
        except EOFError:
            raw = ""
        if raw not in ("y", "yes", "是"):
            say("已取消。")
            return 2

    say()
    failed = 0
    for src, dst in plan:
        try:
            shutil.copy2(src, dst)
            digest = sha256_of(dst)
            expect = next(
                (f["sha256_before"] for f in manifest["files"]
                 if f.get("original") == dst), None)
            mark = "OK" if (not expect or digest == expect) else "!!"
            say("[{}] 已还原 {}".format(mark, dst))
            if mark == "!!":
                failed += 1
        except Exception as e:
            say("[X] 还原失败 {}: {}".format(dst, e))
            failed += 1

    say()
    if failed:
        say("有 {} 个文件还原失败，请检查权限或文件占用。".format(failed))
        return 6

    say("=" * 68)
    say(" 还原完成。")
    say("=" * 68)
    say("下一步：打开 ClashMi 重新连接（或先确认它没在运行再启动）。")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        say()
        say("已中断。")
        sys.exit(130)
