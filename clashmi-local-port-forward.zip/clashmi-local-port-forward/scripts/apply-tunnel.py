#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClashMi 端口转发（tunnels）一键写入脚本
========================================

作用
----
往 ClashMi 实际加载的配置文件里追加一个 tunnels 段，实现：
    访问本机 <localhost_port>  ==  请求原样转发到 <目标域名/IP>:<target_port>

会依次问你：
    1. 目标域名（必填，交互输入，不预设）
    2. 目标真实 IP（回车则自动通过 DoH 解析；解析失败会让你手填）
    3. 本机监听端口（默认 8443）
    4. 目标端口（默认 443）
    5. 出口 proxy（默认自动识别配置里的第一个 select 策略组名）
    6. 是否同时写 Windows hosts（默认否，需要管理员权限）

安全措施
--------
* 写入前强制备份到 backups/<时间戳>/，并记录原始 SHA256
* 全程只做「追加 / 替换自己写入的标记块」，绝不重写别人的内容
* 检测到 ClashMi 正在运行会中止，避免被内存副本回写覆盖
* 行尾符、编码、BOM 状态原样保留

重要说明（为什么 target 必须写 IP）
-----------------------------------
ClashMi 的内置覆写会强制 dns.use-system-hosts = true，
意味着内核会读 Windows hosts 文件。
而这条转发链路又必须靠 hosts 把域名指到 127.0.0.1，
如果不写死 IP，内核解析 target 时同样会拿到 127.0.0.1 -> 自己连自己死循环。
所以本脚本强制让 target 使用真实 IP，并在写 hosts 前再做一次自环校验。

用法
----
双击 run-apply.cmd，或直接运行本文件。
还原：运行 restore-tunnel.py
"""

import ctypes
import hashlib
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
import sys
import time
import urllib.parse
import urllib.request

MARK_BEGIN = "# >>> clashmi-tunnel managed block >>>"
MARK_END = "# <<< clashmi-tunnel managed block <<<"

HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP_ROOT = os.path.join(HERE, "backups")

DEFAULT_APPDATA_BASE = os.path.join(
    os.environ.get("APPDATA", os.path.expanduser("~")), "clashmi", "clashmi"
)

HOSTS_PATH = os.path.join(
    os.environ.get("SystemRoot", r"C:\Windows"), "System32", "drivers", "etc", "hosts"
)


# --------------------------------------------------------------------------
# 基础工具
# --------------------------------------------------------------------------
def say(msg=""):
    print(msg, flush=True)


OPTS = {}


def ask(prompt, default=None, allow_empty_fallback=None, key=None):
    """读一行输入。default 在回车时生效；key 用于命令行非交互模式。"""
    if key and OPTS.get(key) is not None:
        value = str(OPTS[key])
        label = " [{}]".format(default) if default else ""
        say("{}{}: {}".format(prompt, label, value))
        return value
    suffix = " [{}]".format(default) if default else ""
    while True:
        try:
            raw = input("{}{}: ".format(prompt, suffix)).strip()
        except EOFError:
            raw = ""
        if raw:
            return raw
        if default is not None:
            return default
        if allow_empty_fallback is not None:
            return allow_empty_fallback
        if OPTS:
            say("  [X] 非交互模式下缺少必填项，已中止（未做任何修改）。")
            sys.exit(7)
        say("  ! 这一项不能为空，请重新输入。")


def confirm(prompt, default_no=True, key=None):
    if key and OPTS.get(key) is not None:
        value = bool(OPTS[key])
        hint = "[y/N]" if default_no else "[Y/n]"
        say("{} {}: {}".format(prompt, hint, "y" if value else "n"))
        return value
    hint = "[y/N]" if default_no else "[Y/n]"
    try:
        raw = input("{} {}: ".format(prompt, hint)).strip().lower()
    except EOFError:
        # 非交互模式下，--yes 视为同意，否则回落到默认值
        return True if OPTS.get("yes") else (not default_no)
    if not raw:
        return not default_no
    return raw in ("y", "yes", "是")


def parse_args(argv):
    """非交互模式，供脚本/自动化调用。全部可选，缺什么就照旧问什么。"""
    opts = {}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(__doc__)
            sys.exit(0)
        pairs = {
            "--domain": "domain", "--ip": "ip", "--local-port": "local_port",
            "--target-port": "target_port", "--proxy": "proxy",
            "--service-config": "service_config",
        }
        if a in pairs:
            if i + 1 >= len(argv):
                say("[X] {} 后面缺少值".format(a))
                sys.exit(9)
            opts[pairs[a]] = argv[i + 1]
            i += 2
            continue
        if a == "--hosts":
            opts["hosts"] = True
        elif a == "--no-hosts":
            opts["hosts"] = False
        elif a == "--yes":
            opts["yes"] = True
        elif a == "--dry-run":
            opts["dry_run"] = True
        elif a == "--assume-closed":
            opts["assume_closed"] = True
        else:
            say("[X] 未知参数: {}".format(a))
            say("    可用: --domain --ip --local-port --target-port --proxy "
                "--hosts --no-hosts --yes --dry-run --assume-closed")
            sys.exit(9)
        i += 1
    return opts


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def decode_keep_bytes(path):
    """读文件，尽量无损：返回 (text, encoding, newline, had_bom)"""
    with open(path, "rb") as f:
        raw = f.read()
    had_bom = raw.startswith(b"\xef\xbb\xbf")
    if had_bom:
        raw = raw[3:]
    encoding = "utf-8"
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        # hosts 文件常见 ANSI 场景：用 surrogateescape 保证能原样写回
        text = raw.decode("cp1252", errors="surrogateescape")
        encoding = "cp1252-surrogateescape"
    newline = "\r\n" if "\r\n" in text else "\n"
    return text, encoding, newline, had_bom


def encode_write(path, text, encoding, newline, had_bom):
    if encoding == "cp1252-surrogateescape":
        data = text.encode("cp1252", errors="surrogateescape")
    else:
        data = text.encode("utf-8")
    if had_bom:
        data = b"\xef\xbb\xbf" + data
    tmp = path + ".clashmi-tunnel.tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


# --------------------------------------------------------------------------
# 定位 ClashMi 与内核入口文件
# --------------------------------------------------------------------------
def _service_config_candidates():
    """收集所有可能的 service.json 位置。

    教训：ClashMi 在 Windows 上可能同时存在多套安装（例如
    C:\\Program Files\\Clash Mi 与 C:\\Program Files\\ClashMi 是两套不同的东西），
    portable 模式还会把数据放在程序目录下的 portable\\ 里。
    靠 %APPDATA% 猜目录会改错地方，必须以**正在运行的进程**为准。
    """
    cands = []
    # 1) 运行中的进程：clashmiService.exe --service-config=<path>
    try:
        import psutil
        for p in psutil.process_iter(["name", "cmdline"]):
            name = (p.info.get("name") or "").lower()
            if "clash" not in name:
                continue
            for a in (p.info.get("cmdline") or []):
                a = a.strip('"')
                if a.lower().startswith("--service-config="):
                    cands.append(("running-process", a.split("=", 1)[1].strip('"')))
    except ImportError:
        pass
    except Exception:
        pass
    # 2) 常见落点
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        cands.append(("scan", os.path.join(appdata, "clashmi", "clashmi", "service.json")))
        cands.append(("scan", os.path.join(appdata, "clashmi", "service.json")))
    for root in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        if not os.path.isdir(root):
            continue
        try:
            for n in os.listdir(root):
                if "clash" in n.lower():
                    cands.append(("scan", os.path.join(root, n, "portable", "service.json")))
                    cands.append(("scan", os.path.join(root, n, "service.json")))
        except Exception:
            pass
    seen, out = set(), []
    for src, c in cands:
        key = os.path.normcase(os.path.abspath(c))
        if key not in seen:
            seen.add(key)
            out.append((src, c))
    return out


def locate_target_config(forced_svc=None):
    """定位真正在用的那套配置。返回 dict 或 None。

    选择顺序：运行中进程指定的 -> 使用痕迹最新（profiles.json 等 mtime 最大）的。
    """
    cands = []
    if forced_svc:
        cands.append(("forced", forced_svc))
    cands.extend(_service_config_candidates())

    say("  候选 service.json:")
    valid = []
    for src, path in cands:
        if not os.path.isfile(path):
            say("    [不存在] {}".format(path))
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                svc = json.load(f)
        except Exception as e:
            say("    [读失败] {} ({})".format(path, e))
            continue
        core = svc.get("core_path") or ""
        base = svc.get("base_dir") or os.path.dirname(path)
        fresh = 0.0
        for probe in ("profiles.json", "service.json", "setting.json",
                      "service_core.log", "app.log"):
            pp = os.path.join(base, probe)
            if os.path.isfile(pp):
                fresh = max(fresh, os.path.getmtime(pp))
        has_core = bool(core) and os.path.isfile(core)
        mark = "运行中" if src == "running-process" else ("指定" if src == "forced" else "扫描")
        say("    [{}] {}  版本={}  core={}".format(
            mark, base, svc.get("version", "?"),
            "存在" if has_core else "缺失"))
        valid.append({
            "svc_path": path, "base": base, "core": core,
            "version": svc.get("version", "?"), "source": src,
            "fresh": fresh, "has_core": has_core,
        })
    if not valid:
        return None

    running = [v for v in valid if v["source"] == "running-process" and v["has_core"]]
    forced = [v for v in valid if v["source"] == "forced" and v["has_core"]]
    pickable = running or forced or [v for v in valid if v["has_core"]] or valid
    picked = max(pickable, key=lambda v: (v["fresh"], v["source"] != "scan"))

    if not picked["has_core"]:
        prof_dir = os.path.join(picked["base"], "profiles")
        if os.path.isdir(prof_dir):
            yamls = [os.path.join(prof_dir, n) for n in os.listdir(prof_dir)
                     if n.lower().endswith((".yaml", ".yml"))]
            if yamls:
                yamls.sort(key=lambda p: os.path.getmtime(p), reverse=True)
                picked["core"] = yamls[0]
                picked["has_core"] = True
                say("    ! core_path 缺失，退回 profiles/ 里最新的一份")
    if not picked["has_core"]:
        return None
    return picked


def core_is_running():
    """REST API 端口能连上，说明内核在跑。"""
    try:
        with socket.create_connection(("127.0.0.1", 9090), timeout=1.5):
            return True
    except OSError:
        pass
    # 回退：查进程。注意中文 Windows 的 tasklist 输出是 GBK，不能按 UTF-8 硬解
    for exe in ("clashmi.exe", "clashmiService.exe"):
        try:
            out = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq " + exe, "/FO", "CSV", "/NH"],
                capture_output=True, timeout=15,
            ).stdout.decode("utf-8", errors="replace").lower()
            if exe.lower() in out:
                return True
        except Exception:
            continue
    return False


# --------------------------------------------------------------------------
# 解析真实 IP（走 DoH，绕开本机 hosts）
# --------------------------------------------------------------------------
PRIVATE_PREFIXES = (
    "127.", "10.", "0.", "169.254.", "255.", "224.", "225.", "226.", "227.",
    "228.", "229.", "230.", "231.", "232.", "233.", "234.", "235.", "236.",
    "237.", "238.", "239.",
)


def looks_unroutable(ip):
    if ip.startswith(PRIVATE_PREFIXES):
        return True
    if ip.startswith("192.168."):
        return True
    m = re.match(r"^172\.(\d+)\.", ip)
    if m and 16 <= int(m.group(1)) <= 31:
        return True
    if ip == "127.0.0.1":
        return True
    return False


def resolve_via_doh(domain, timeout=7):
    endpoints = [
        ("https://dns.alidns.com/resolve?name={}&type=A", None),
        ("https://cloudflare-dns.com/dns-query?name={}&type=A", "application/dns-json"),
    ]
    ctx = ssl.create_default_context()
    for tpl, accept in endpoints:
        url = tpl.format(urllib.parse.quote(domain))
        try:
            req = urllib.request.Request(url)
            if accept:
                req.add_header("accept", accept)
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            ips = [a.get("data") for a in data.get("Answer", []) if a.get("type") == 1]
            ips = [i for i in ips if i]
            if ips:
                return ips
        except Exception:
            continue
    return []


# --------------------------------------------------------------------------
# 备份
# --------------------------------------------------------------------------
def make_backup(files, note):
    stamp = time.strftime("%Y%m%d-%H%M%S")
    bdir = os.path.join(BACKUP_ROOT, stamp)
    os.makedirs(bdir, exist_ok=True)
    manifest = {"time": stamp, "note": note, "files": []}
    for src in files:
        if not src or not os.path.isfile(src):
            continue
        name = src.replace(":", "").replace("\\", "__").replace("/", "__")
        dst = os.path.join(bdir, name)
        shutil.copy2(src, dst)
        manifest["files"].append({
            "original": src,
            "backup": os.path.basename(dst),
            "sha256_before": sha256_of(src),
            "size": os.path.getsize(src),
        })
    with open(os.path.join(bdir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    return bdir, manifest


# --------------------------------------------------------------------------
# 生成 tunnels 块
# --------------------------------------------------------------------------
def detect_first_select_group(text):
    m = re.search(r"-\s*\{\s*name:\s*([^,{}]+?)\s*,\s*type:\s*select\b", text)
    if m:
        return m.group(1).strip().strip("'\"")
    return None


def build_block(local_port, target_ip, target_port, proxy):
    return "\n".join([
        MARK_BEGIN,
        "tunnels:",
        "  - network: [tcp]",
        "    address: 127.0.0.1:{}".format(local_port),
        "    target: {}:{}".format(target_ip, target_port),
        "    proxy: {}".format(yaml_scalar(proxy)),
        MARK_END,
    ])


def yaml_scalar(value):
    """中文等非 ASCII 值统一加单引号，YAML 里最保险。"""
    if re.match(r"^[A-Za-z0-9_.\-]+$", value):
        return value
    return "'{}'".format(value.replace("'", "''"))


def strip_existing_block(text):
    if MARK_BEGIN not in text:
        return text, False
    pattern = re.compile(
        re.escape(MARK_BEGIN) + r".*?" + re.escape(MARK_END) + r"[ \t]*\r?\n?",
        re.DOTALL,
    )
    return pattern.sub("", text, count=1), True


# --------------------------------------------------------------------------
# hosts
# --------------------------------------------------------------------------
def hosts_has_entry(text, domain):
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split()
        if len(parts) >= 2 and domain.lower() in [p.lower() for p in parts[1:]]:
            return True, line
    return False, None


def add_hosts_entry(text, newline, domain, ip):
    block = newline.join([
        MARK_BEGIN,
        "{}\t{}".format(ip, domain),
        MARK_END,
    ])
    if not text.endswith(("\n", "\r")):
        text += newline
    return text + block + newline


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def main():
    global OPTS
    OPTS = parse_args(sys.argv[1:])

    say("=" * 68)
    say(" ClashMi tunnels 一键写入")
    say("=" * 68)
    if OPTS:
        say(" 启动参数: {}".format(
            " ".join("{}={}".format(k, v) for k, v in OPTS.items())))
    say()

    running = core_is_running()
    if running:
        say("[!] ClashMi 正在运行。")
        say("    好消息：脚本会用它的进程参数精确定位到**真正在用的那一套**配置。")
        say("    要注意：改完必须断开重连一次才生效；个别版本退出时可能回写配置，")
        say("    所以改完建议再确认一次 tunnels 段还在。")
        say()
        if not confirm("继续（在 ClashMi 运行状态下修改）", default_no=True,
                       key="assume_closed"):
            say("已取消，未做任何修改。")
            return 2
    else:
        say("[OK] 未检测到 ClashMi 在运行。")
    say()

    say("定位目标：优先用运行中进程的 --service-config，其次比对各套配置的最近使用时间。")
    found = locate_target_config(OPTS.get("service_config"))
    if not found:
        say("[X] 找不到可用的 ClashMi 配置。")
        say("    可用 --service-config <path> 手工指定那一套的 service.json。")
        return 3
    cfg, base = found["core"], found["base"]
    say()
    say("[OK] 选定目录 : {}（版本 {}）".format(base, found["version"]))
    say("[OK] 定位来源 : {}".format(
        {"running-process": "运行中进程参数",
         "forced": "命令行指定"}.get(found["source"], "扫描 + 最近使用时间")))
    say("[OK] 内核入口 : {}".format(cfg))
    say()

    text, encoding, newline, had_bom = decode_keep_bytes(cfg)
    say("     编码 {} / 行尾 {!r} / BOM {} / 共 {} 行".format(
        encoding, newline, "有" if had_bom else "无", len(text.splitlines())))

    if re.search(r"(?m)^tunnels\s*:", text) and MARK_BEGIN not in text:
        say()
        say("[X] 配置里已经存在一个不归本脚本管的 tunnels: 块。")
        say("    为避免互相踩踏，脚本不再继续。请手工处理那一块后重试。")
        return 4
    say()

    # ---- 交互 ----
    say("-" * 68)
    say(" 第 1 步：目标域名")
    say("-" * 68)
    domain = ask("目标域名（例如 api.example.com）", key="domain")
    domain = domain.strip().strip(".").lower()
    if not re.match(r"^[a-z0-9.\-]+$", domain) or "." not in domain:
        say("[X] 域名格式看起来不对: {}".format(domain))
        return 5
    say()

    say("-" * 68)
    say(" 第 2 步：目标真实 IP")
    say("-" * 68)
    say("（target 必须写 IP，原因见脚本头部说明；不走本机 hosts 解析）")
    auto_ips = resolve_via_doh(domain)
    target_ip = ""
    if OPTS.get("ip"):
        target_ip = str(OPTS["ip"]).strip()
        say("使用命令行指定的 IP: {}".format(target_ip))
    elif auto_ips:
        say("DoH 解析结果: {}".format(", ".join(auto_ips)))
        pick = ask("使用哪个 IP（回车用第一个，或直接输入其它 IP）",
                   default=auto_ips[0], key="ip")
        target_ip = pick.strip()
    else:
        say("! 自动解析失败（没网 / DoH 被拦 / 域名不存在）")
        target_ip = ask("请手工输入目标真实 IP", key="ip").strip()
    if not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", target_ip):
        say("[X] 不是合法的 IPv4: {}".format(target_ip))
        return 5
    if looks_unroutable(target_ip):
        say("[!] {} 看起来是内网/保留地址。如果它确实是你想转发的目标，可以继续。".format(target_ip))
        if not confirm("确认继续", default_no=True):
            say("已取消，未做任何修改。")
            return 2
    say()

    say("-" * 68)
    say(" 第 3 步：端口")
    say("-" * 68)
    local_port = ask("本机监听端口", default="8443", key="local_port").strip()
    target_port = ask("目标端口", default="443", key="target_port").strip()
    for name, val in (("本机监听端口", local_port), ("目标端口", target_port)):
        if not val.isdigit() or not (1 <= int(val) <= 65535):
            say("[X] {} 不合法: {}".format(name, val))
            return 5
    if int(local_port) in (7890, 7891, 9090, 9091):
        say("[!] {} 可能与 ClashMi 自身端口冲突，建议换一个（如 8443）。".format(local_port))
        if not confirm("仍然继续", default_no=True):
            return 2
    say()

    say("-" * 68)
    say(" 第 4 步：出口 proxy")
    say("-" * 68)
    group = detect_first_select_group(text)
    default_proxy = group or "DIRECT"
    if group:
        say("从配置里识别到策略组: {}".format(group))
    say("可填：策略组名（走机场） / DIRECT（本机网络直连）")
    proxy = ask("proxy", default=default_proxy, key="proxy").strip()
    say()

    say("-" * 68)
    say(" 第 5 步：Windows hosts")
    say("-" * 68)
    say("要让「用域名访问本机端口」成立，需要把域名指到 127.0.0.1。")
    say("（否则请求会跑到真实的公网地址，压根不经过你这条 tunnel）")
    want_hosts = confirm("现在写入 hosts（需要管理员权限）", default_no=True, key="hosts")
    say()

    # ---- 预览与确认 ----
    block = build_block(local_port, target_ip, target_port, proxy)
    say("=" * 68)
    say(" 即将写入 {} 的内容".format(os.path.basename(cfg)))
    say("=" * 68)
    say(block)
    say()
    if want_hosts:
        say("以及 {} 追加:".format(HOSTS_PATH))
        say("  {}\t{}".format(target_ip, domain))
        say()
    if OPTS.get("dry_run"):
        say("--dry-run：预览到此结束，未做任何修改，也未创建备份。")
        return 0

    if not confirm("确认写入", default_no=False, key="yes"):
        say("已取消，未做任何修改。")
        return 2

    # ---- 备份 ----
    files_to_backup = [cfg]
    hosts_text = hosts_encoding = hosts_newline = hosts_bom = None
    hosts_will_change = False
    if want_hosts and os.path.isfile(HOSTS_PATH):
        hosts_text, hosts_encoding, hosts_newline, hosts_bom = decode_keep_bytes(HOSTS_PATH)
        exists, line = hosts_has_entry(hosts_text, domain)
        if exists:
            say("[!] hosts 里已经有 {} 的记录: {}".format(domain, line.strip()))
            want_hosts = confirm("仍然继续（不会重复添加，会原地更新）", default_no=False)
        hosts_will_change = want_hosts
        if hosts_will_change:
            files_to_backup.append(HOSTS_PATH)

    bdir, manifest = make_backup(
        files_to_backup,
        "apply tunnels {}:{} -> {}:{} proxy={}".format(
            local_port, "127.0.0.1", target_ip, target_port, proxy),
    )
    say("[OK] 已备份到: {}".format(bdir))
    for item in manifest["files"]:
        say("     {}  sha256={}...".format(
            item["original"], item["sha256_before"][:16]))
    say()

    # ---- 写入配置 ----
    new_text, replaced = strip_existing_block(text)
    if not new_text.endswith(("\n", "\r")):
        new_text += newline
    if replaced:
        new_text += newline + block + newline
    else:
        new_text += newline + block + newline
    encode_write(cfg, new_text, encoding, newline, had_bom)
    say("[OK] 已写入配置，{} 模式。".format("替换旧标记块" if replaced else "追加新块"))

    # 校验：能读回、标记在、tunnels 在
    check, _, _, _ = decode_keep_bytes(cfg)
    ok_block = MARK_BEGIN in check and "tunnels:" in check
    say("[{}] 写入后自检: 标记块 {}".format("OK" if ok_block else "!!", "存在" if ok_block else "缺失"))
    if ok_block:
        try:
            import yaml
            yaml.safe_load(check)
            say("[OK] YAML 解析通过（已用本机 PyYAML 校验）")
        except ImportError:
            say("[--] 本机没有 PyYAML，跳过整体校验（结构未动，只追加了顶层键，通常无碍）")
        except Exception as e:
            say("[X] YAML 解析失败: {}".format(e))
            say("    立刻运行 restore-tunnel.py 还原！")
            return 6

    # ---- 写 hosts ----
    if hosts_will_change:
        if not is_admin():
            say()
            say("[X] 写 hosts 需要管理员权限，当前不是管理员。")
            say("    请用「以管理员身份运行」重新执行本脚本，或忽略 hosts 这一步。")
            say("    配置文件已经改好了，hosts 可以稍后单独补。")
        else:
            exists, _ = hosts_has_entry(hosts_text, domain)
            hnew, _ = strip_existing_block(hosts_text)
            if exists:
                lines = []
                for line in hnew.splitlines():
                    s = line.strip()
                    if s and not s.startswith("#") and domain in [p.lower() for p in s.split()[1:]]:
                        continue
                    lines.append(line)
                hnew = hosts_newline.join(lines)
                if not hnew.endswith(("\n", "\r")):
                    hnew += hosts_newline
            hnew = add_hosts_entry(hnew, hosts_newline, domain, target_ip)
            encode_write(HOSTS_PATH, hnew, hosts_encoding, hosts_newline, hosts_bom)
            say("[OK] 已写入 hosts: {} -> {}".format(domain, target_ip))

    say()
    say("=" * 68)
    say(" 完成。接下来：")
    say("=" * 68)
    say(" 1. 打开 ClashMi，确认连接正常（若报 yaml 错误，立刻运行 restore-tunnel.py）")
    say(" 2. 断开再重新连接一次，让内核加载新配置")
    # 入口是本机监听地址，不是目标地址；协议由目标端口推断（443→https，其余→http）
    local_scheme = "https" if str(target_port) == "443" else "http"
    say(" 3. 访问  {}://127.0.0.1:{}/".format(local_scheme, local_port))
    say("        （入口固定是本机监听地址；真正目标是 {}:{}，由内核转发，"
        "客户端只管访问上面这个地址）".format(target_ip, target_port))
    say(" 4. 想确认生效：ClashMi「面板 - 连接」里应出现这条记录，")
    say("    或在 ClashMi 的 runtime profile 里搜 tunnels 段")
    say()
    say(" 注意：订阅更新（默认每天一次）会用新文件覆盖配置，")
    say("       届时重新运行本脚本即可。备份目录: {}".format(BACKUP_ROOT))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        say()
        say("已中断。若在写入过程中中断，请检查 backups/ 并运行 restore-tunnel.py。")
        sys.exit(130)
