#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClashMi tunnels 生效性检验（只读，不修改任何东西）
=================================================

按顺序做 5 项检查，最后给一个结论表。任意一项失败都会指出卡在哪一层。

检查项
------
0. 前置：ClashMi 内核是否在跑（127.0.0.1:9090 可连）
1. 监听：127.0.0.1:<local_port> 是否 LISTENING，属于哪个 PID
   —— 这一项通过 = 内核**接受了 tunnels 配置**，与出站节点死活无关
2. 内核配置：内核入口文件里的 tunnels 段
   （REST API 的 /configs **不返回** tunnels 字段，实测为 null，别看那里）
3. 运行时快照：service_core_runtime_profile.yaml 里有没有 tunnels
4. 内核日志：service_core.log 有没有 yaml / tunnels 相关报错
5. 端到端：对 127.0.0.1:<local_port> 发真实请求
   —— 这一项通过 = 整条链路（含出站节点）通了
   协议按配置里该条 tunnel 的 target 端口自动判：target 是 :80 -> 明文 HTTP；
   其余（:443 等）-> 带真实 SNI 的 TLS。可用 --scheme http|https 强制。
   target 是 :80 时额外做一次 Host=<目标IP> 的对照，用来暴露“目标按 Host 分虚拟主机”。

用法
----
双击 run-verify.cmd
python verify-tunnel.py --local-port 8443                      # 协议自动判
python verify-tunnel.py --domain example.com --local-port 8443  # HTTPS 时指定 SNI
python verify-tunnel.py --local-port 8443 --scheme http         # 强制明文
"""

import json
import os
import re
import socket
import ssl
import subprocess
import sys
import urllib.request

CLASHMI_DATA_DIR = os.path.join(
    os.environ.get("APPDATA", os.path.expanduser("~")), "clashmi", "clashmi"
)

STATE = {"pass": [], "fail": [], "warn": [], "info": []}


def say(msg=""):
    print(msg, flush=True)


def ok(name, detail=""):
    STATE["pass"].append(name)
    say("  [PASS] {}{}".format(name, ("  -- " + detail) if detail else ""))


def bad(name, detail=""):
    STATE["fail"].append(name)
    say("  [FAIL] {}{}".format(name, ("  -- " + detail) if detail else ""))


def warn(name, detail=""):
    STATE["warn"].append(name)
    say("  [WARN] {}{}".format(name, ("  -- " + detail) if detail else ""))


def info(detail):
    STATE["info"].append(detail)
    say("  [INFO] {}".format(detail))


def find_active_install():
    """按运行中进程的 --service-config 定位真正在用的那一套。

    教训：Windows 上可能同时存在多套 ClashMi（C:\\Program Files\\Clash Mi 与
    C:\\Program Files\\ClashMi 是两个不同的东西），portable 模式的数据还在程序目录下。
    返回 (core_path, base_dir, service_json_path)。
    """
    try:
        import psutil
        for p in psutil.process_iter(["name", "cmdline"]):
            if "clash" not in (p.info.get("name") or "").lower():
                continue
            for a in (p.info.get("cmdline") or []):
                a = a.strip('"')
                if a.lower().startswith("--service-config="):
                    svc = a.split("=", 1)[1].strip('"')
                    if os.path.isfile(svc):
                        with open(svc, "r", encoding="utf-8") as f:
                            d = json.load(f)
                        return d.get("core_path", ""), d.get("base_dir", ""), svc
    except Exception:
        pass
    svc = os.path.join(CLASHMI_DATA_DIR, "service.json")
    if os.path.isfile(svc):
        try:
            with open(svc, "r", encoding="utf-8") as f:
                d = json.load(f)
            return d.get("core_path", ""), d.get("base_dir", ""), svc
        except Exception:
            pass
    return "", "", ""


def get_secret(base=""):
    p = os.path.join(base or CLASHMI_DATA_DIR, "service_core_patch_final.json")
    if os.path.isfile(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f).get("secret", "")
        except Exception:
            pass
    return ""


def tunnels_in_yaml_file(path):
    """返回 (是否含非空 tunnels, 说明)。注意 tunnels: [] 是内核序列化出的空默认值，不算。"""
    if not path or not os.path.isfile(path):
        return False, "文件不存在"
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception as e:
        return False, "读失败: {}".format(e)
    try:
        import yaml
        doc = yaml.safe_load(text)
        if isinstance(doc, dict) and doc.get("tunnels"):
            return True, json.dumps(doc["tunnels"], ensure_ascii=False)[:220]
        return False, "解析成功，但 tunnels 为空或不存在"
    except ImportError:
        pass
    except Exception as e:
        return False, "YAML 解析失败: {}".format(str(e)[:100])
    m = re.search(r"(?m)^tunnels\s*:\s*(?!\[\s*\]\s*$)(.+)$", text)
    if m:
        return True, m.group(1).strip()[:220]
    if re.search(r"(?m)^tunnels\s*:\s*$", text):
        return True, "tunnels: 后接多行内容"
    return False, "未找到非空 tunnels 段"


def netstat_listen(port):
    """返回 [(local_addr, pid), ...]，只看 LISTENING。"""
    hits = []
    try:
        out = subprocess.run(["netstat", "-ano"], capture_output=True, timeout=25
                             ).stdout.decode("utf-8", errors="replace")
    except Exception as e:
        info("netstat 调用失败: {}".format(e))
        return hits
    for line in out.splitlines():
        if "LISTENING" not in line.upper():
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        local, pid = parts[1], parts[-1]
        if local.endswith(":" + str(port)):
            hits.append((local, pid))
    return hits


def pid_to_name(pid):
    try:
        out = subprocess.run(
            ["tasklist", "/FI", "PID eq {}".format(pid), "/FO", "CSV", "/NH"],
            capture_output=True, timeout=15,
        ).stdout.decode("utf-8", errors="replace").strip()
        if out and "," in out:
            return out.split(",")[0].strip('"')
    except Exception:
        pass
    return "?"


def api_get(path, secret):
    req = urllib.request.Request("http://127.0.0.1:9090" + path)
    if secret:
        req.add_header("Authorization", "Bearer " + secret)
    with urllib.request.urlopen(req, timeout=6) as r:
        return json.loads(r.read().decode("utf-8"))


def tls_probe(host, port, domain, timeout=12):
    """连到 host:port，但只要 SNI/Host 用 domain，HTTP 请求原样发过去。"""
    ctx = ssl.create_default_context()
    s = socket.create_connection((host, port), timeout=timeout)
    try:
        ss = ctx.wrap_socket(s, server_hostname=domain)
        req = (
            "GET / HTTP/1.1\r\n"
            "Host: {d}\r\n"
            "User-Agent: clashmi-tunnel-verify\r\n"
            "Accept: */*\r\n"
            "Connection: close\r\n\r\n"
        ).format(d=domain).encode("ascii")
        ss.sendall(req)
        buf = b""
        while len(buf) < 8192:
            chunk = ss.recv(4096)
            if not chunk:
                break
            buf += chunk
            if b"\r\n\r\n" in buf:      # 收到头就停，别等 keep-alive 把超时耗光
                break
        text = buf.decode("utf-8", errors="replace")
        first = text.split("\r\n")[0] if text else "(空响应)"
        cert = ss.getpeercert()
        cn = ""
        if cert:
            for tup in cert.get("subject", ()):
                for k, v in tup:
                    if k == "commonName":
                        cn = v
        return True, first, cn
    finally:
        try:
            s.close()
        except Exception:
            pass


def http_probe(host, port, host_header, timeout=12):
    """明文 HTTP 探测：连到 host:port，Host 头用 host_header。

    target 是 :80 时必须走这里 —— 用 TLS 探会得到 WRONG_VERSION_NUMBER
    （明文服务器收到 ClientHello 直接当垃圾），那是**假 FAIL**，不是 tunnel 坏了。
    """
    s = socket.create_connection((host, port), timeout=timeout)
    try:
        req = (
            "GET / HTTP/1.1\r\n"
            "Host: {h}\r\n"
            "User-Agent: clashmi-tunnel-verify\r\n"
            "Accept: */*\r\n"
            "Connection: close\r\n\r\n"
        ).format(h=host_header).encode("ascii", "replace")
        s.sendall(req)
        buf = b""
        while len(buf) < 8192:
            chunk = s.recv(4096)
            if not chunk:
                break
            buf += chunk
            if b"\r\n\r\n" in buf:
                break
        text = buf.decode("utf-8", errors="replace")
        return True, (text.split("\r\n")[0] if text else "(空响应)")
    finally:
        try:
            s.close()
        except Exception:
            pass


def tunnel_for(core_path, local_port):
    """从内核入口配置里取出 address 端口 == local_port 的那条 tunnel（没有则 None）。"""
    if not core_path or not os.path.isfile(core_path):
        return None
    try:
        import yaml
        with open(core_path, "r", encoding="utf-8", errors="replace") as f:
            doc = yaml.safe_load(f.read())
    except Exception:
        return None
    if not isinstance(doc, dict):
        return None
    for t in (doc.get("tunnels") or []):
        if isinstance(t, dict) and str(t.get("address", "")).endswith(":" + str(local_port)):
            return t
    return None


def main():
    argv = sys.argv[1:]
    domain = ""
    local_port = "8443"
    scheme = "auto"
    for i, a in enumerate(argv):
        if a == "--domain" and i + 1 < len(argv):
            domain = argv[i + 1]
        elif a == "--local-port" and i + 1 < len(argv):
            local_port = argv[i + 1]
        elif a == "--scheme" and i + 1 < len(argv):
            scheme = argv[i + 1].strip().lower()

    say("=" * 70)
    say(" ClashMi tunnels 生效性检验")
    say(" 目标 {} / 本机端口 {} / 协议 {}".format(domain or "(按配置判)", local_port, scheme))
    say("=" * 70)

    # ---- 0 前置 ----
    say()
    say("[0] 前置检查：内核是否在运行")
    core_path, base_dir, svc_path = find_active_install()
    core_up = False
    try:
        with socket.create_connection(("127.0.0.1", 9090), timeout=2):
            core_up = True
    except OSError as e:
        info("9090 不可连: {}".format(e))
    if not core_up:
        bad("内核未运行", "请先打开 ClashMi 并点击连接，再重新运行本检验")
        summary()
        return 2
    ok("内核在运行", "127.0.0.1:9090 可连")
    sec = get_secret(base_dir)
    try:
        req = urllib.request.Request("http://127.0.0.1:9090/version")
        if sec:
            req.add_header("Authorization", "Bearer " + sec)
        ver = json.loads(urllib.request.urlopen(req, timeout=5).read().decode("utf-8"))
        ok("内核版本", "mihomo {} (meta={})".format(ver.get("version"), ver.get("meta")))
    except Exception as e:
        warn("读不到内核版本", str(e)[:100])
    if svc_path:
        info("在用实例: {}".format(base_dir or "(未知)"))
        info("service.json: {}".format(svc_path))

    # ---- 1 监听 ----
    say()
    say("[1] 本机端口是否被内核接管（tunnels 是否被接受）")
    hits = netstat_listen(local_port)
    if not hits:
        bad("127.0.0.1:{} 没有 LISTENING".format(local_port),
            "内核没建立这条 tunnel：可能配置没生效、被订阅更新覆盖，或内核版本不支持 tunnels")
        info("下一步：断开重连一次；仍不行就查 service_core.log 有无 yaml 报错")
    else:
        for local, pid in hits:
            name = pid_to_name(pid)
            if "clash" in name.lower():
                ok("{} LISTENING".format(local), "属主 {} (PID {})".format(name, pid))
            else:
                warn("{} LISTENING 但属主是 {} (PID {})".format(local, name, pid),
                     "不是 ClashMi 内核，可能端口被别的程序占了")

    # ---- 2 内核入口文件 ----
    say()
    say("[2] 内核实际加载的配置文件里的 tunnels 段")
    if core_path:
        info("内核入口: {}".format(core_path))
        has, detail = tunnels_in_yaml_file(core_path)
        if has:
            ok("入口文件含非空 tunnels", detail)
        else:
            bad("入口文件里没有 tunnels", detail)
            info("多套安装时很容易写错地方；也可能是订阅更新把它覆盖了")
    else:
        warn("定位不到内核入口", "未从运行进程或 service.json 取到 core_path")

    # ---- 3 运行时快照（可选） ----
    say()
    say("[3] 运行时快照文件（部分版本不生成）")
    snap = os.path.join(base_dir or CLASHMI_DATA_DIR, "service_core_runtime_profile.yaml")
    if not os.path.isfile(snap):
        warn("快照文件不存在", "该版本不保存运行时快照，属正常，不影响判断")
    else:
        has, detail = tunnels_in_yaml_file(snap)
        if has:
            ok("runtime profile 含非空 tunnels", detail)
        else:
            warn("runtime profile 里 tunnels 为空/缺失", detail)

    # ---- 4 日志 ----
    say()
    say("[4] 内核日志")
    log = os.path.join(base_dir or CLASHMI_DATA_DIR, "service_core.log")
    if not os.path.isfile(log):
        warn("日志文件不存在", log)
    else:
        try:
            with open(log, "r", encoding="utf-8", errors="replace") as f:
                lines = f.read().splitlines()
            hits = [l for l in lines
                    if re.search(r"yaml|tunnel", l, re.I) and re.search(r"error|warn|fail", l, re.I)]
            if hits:
                bad("日志里有 yaml/tunnels 相关报错", "{} 条，最后一条：{}".format(len(hits), hits[-1][:160]))
            else:
                ok("日志无 yaml/tunnels 报错", "共 {} 行".format(len(lines)))
            tail = lines[-3:]
            for l in tail:
                info("日志尾部: {}".format(l[:160]))
        except Exception as e:
            warn("读日志失败", str(e)[:120])

    # ---- 5 端到端 ----
    say()
    t = tunnel_for(core_path, local_port)
    target = str((t or {}).get("target", ""))
    if scheme == "auto":
        tport = target.rsplit(":", 1)[-1] if ":" in target else ""
        scheme = "http" if tport == "80" else "https"
    if target:
        info("命中配置里的 tunnel: {} -> {} (proxy={})".format(
            (t or {}).get("address", "?"), target, (t or {}).get("proxy", "?")))
    else:
        warn("配置里没找到本机端口对应的 tunnel", "第 5 项按 --scheme {} 盲探".format(scheme))

    if scheme == "http":
        say("[5] 端到端：明文 HTTP 请求本机端口（target 是 HTTP，无 SNI / 无证书）")
        host_header = domain or "localhost"
        try:
            good, first = http_probe("127.0.0.1", int(local_port), host_header)
            if first.startswith("HTTP/"):
                ok("HTTP 响应成功", "{}（Host: {}）".format(first, host_header))
                info("整条链路已通：客户端 -> 本机 {} -> ClashMi tunnel -> {}".format(
                    local_port, target or domain or "?"))
            else:
                bad("响应不是 HTTP", first[:120])
        except Exception as e:
            bad("端到端请求失败", "{}: {}".format(type(e).__name__, str(e)[:200]))
            info("分层排查：第 1 项 PASS 但这里 FAIL -> tunnel 已建立，问题在出站节点；")
            info("          第 1 项也 FAIL -> 配置没被内核接受，先解决那一层")
        # Host 对照：tunnel 是 L4，不改 Host。目标按 server_name 分虚拟主机时，
        # Host 换成目标 IP 往往会落到另一个 vhost（403 / 404 / 另一个应用）。
        ip = target.rsplit(":", 1)[0] if ":" in target else ""
        if ip and ip != host_header:
            try:
                good2, first2 = http_probe("127.0.0.1", int(local_port), ip)
                if first2 != first:
                    warn("Host 头影响路由", "Host: {} -> {}（与上面不同，目标按 Host 分虚拟主机）".format(ip, first2))
                else:
                    info("Host 对照：Host: {} 响应一致，目标不按 Host 分流".format(ip))
            except Exception as e:
                warn("Host 对照请求失败", "Host: {} -> {}".format(ip, str(e)[:80]))
    else:
        say("[5] 端到端：带真实 SNI 请求本机端口")
        sni = domain or "example.com"
        if not domain:
            info("未指定 --domain，SNI 用占位 {}；HTTPS 目标应传真实域名".format(sni))
        try:
            good, first, cn = tls_probe("127.0.0.1", int(local_port), sni)
            if good:
                ok("TLS 握手 + HTTP 响应成功", "{}（证书 CN={}）".format(first, cn or "?"))
                if first.startswith("HTTP/"):
                    info("整条链路已通：客户端 -> 本机 {} -> ClashMi tunnel -> {}".format(
                        local_port, target or sni))
            else:
                bad("请求未成功")
        except ssl.SSLCertVerificationError as e:
            warn("TLS 证书校验失败", str(e)[:160])
            info("若证书 CN 与 {} 不符，说明流量没到目标站点，可能出站节点有问题".format(sni))
        except Exception as e:
            bad("端到端请求失败", "{}: {}".format(type(e).__name__, str(e)[:200]))
            info("分层排查：第 1 项 PASS 但这里 FAIL -> tunnel 已建立，问题在出站节点；")
            info("          第 1 项也 FAIL -> 配置没被内核接受，先解决那一层")

    return summary()


def summary():
    say()
    say("=" * 70)
    say(" 结论")
    say("=" * 70)
    say("  PASS {} 项 / FAIL {} 项 / WARN {} 项".format(
        len(STATE["pass"]), len(STATE["fail"]), len(STATE["warn"])))
    if STATE["fail"]:
        say()
        say("  失败项：")
        for f in STATE["fail"]:
            say("    - {}".format(f))
    if STATE["warn"]:
        say()
        say("  需留意：")
        for w in STATE["warn"]:
            say("    - {}".format(w))
    say()
    if not STATE["fail"]:
        say("  => tunnels 已生效。")
        return 0
    say("  => 尚未完全生效，见上面失败项。")
    return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        say()
        say("已中断。")
        sys.exit(130)
