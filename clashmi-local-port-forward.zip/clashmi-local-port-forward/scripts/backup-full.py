#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClashMi 配置目录全量备份
========================

把整个 ClashMi 用户数据目录 + Windows hosts 文件完整复制走，并生成带 SHA256 的清单。

特点
----
* 全量复制，不是只挑几个文件
* 目标目录：backups/manual-full-<时间戳>/
* 清单 manifest.json 记录每个文件的相对路径、大小、SHA256，可事后校验
* 只读源目录，不做任何删除或修改

用法
----
双击 run-backup-full.cmd，或  python backup-full.py [备注文字]
"""

import hashlib
import json
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP_ROOT = os.path.join(HERE, "backups")

CLASHMI_DATA_DIR = os.path.join(
    os.environ.get("APPDATA", os.path.expanduser("~")), "clashmi", "clashmi"
)
HOSTS_PATH = os.path.join(
    os.environ.get("SystemRoot", r"C:\Windows"), "System32", "drivers", "etc", "hosts"
)


def say(msg=""):
    print(msg, flush=True)


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 256), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_tree(src_root, dst_root):
    entries = []
    for dirpath, dirnames, filenames in os.walk(src_root):
        rel_dir = os.path.relpath(dirpath, src_root)
        target_dir = os.path.join(dst_root, rel_dir) if rel_dir != "." else dst_root
        os.makedirs(target_dir, exist_ok=True)
        for name in filenames:
            src = os.path.join(dirpath, name)
            dst = os.path.join(target_dir, name)
            rel = os.path.relpath(src, src_root)
            try:
                shutil.copy2(src, dst)
                entries.append({
                    "rel": rel.replace("\\", "/"),
                    "size": os.path.getsize(src),
                    "sha256": sha256_of(src),
                })
            except Exception as e:
                entries.append({"rel": rel.replace("\\", "/"), "error": str(e)})
    return entries


def main():
    note = " ".join(sys.argv[1:]).strip() or "全量备份"
    stamp = time.strftime("%Y%m%d-%H%M%S")
    out_dir = os.path.join(BACKUP_ROOT, "manual-full-" + stamp)

    say("=" * 68)
    say(" ClashMi 配置目录全量备份")
    say("=" * 68)
    say()
    say("源目录: {}".format(CLASHMI_DATA_DIR))
    say("目标  : {}".format(out_dir))
    say()

    if not os.path.isdir(CLASHMI_DATA_DIR):
        say("[X] 源目录不存在，备份中止，未做任何写入。")
        return 3

    os.makedirs(out_dir, exist_ok=True)

    data_dst = os.path.join(out_dir, "clashmi-config")
    say("... 复制配置目录")
    entries = copy_tree(CLASHMI_DATA_DIR, data_dst)

    # 当前配置里内核实际加载的那个文件单独点出来，方便一眼找到
    core_path = ""
    svc = os.path.join(CLASHMI_DATA_DIR, "service.json")
    if os.path.isfile(svc):
        try:
            with open(svc, "r", encoding="utf-8") as f:
                core_path = json.load(f).get("core_path", "")
        except Exception:
            pass

    hosts_entry = None
    if os.path.isfile(HOSTS_PATH):
        say("... 复制 hosts 文件")
        hdst = os.path.join(out_dir, "hosts.orig")
        try:
            shutil.copy2(HOSTS_PATH, hdst)
            hosts_entry = {
                "original": HOSTS_PATH,
                "rel": "hosts.orig",
                "size": os.path.getsize(HOSTS_PATH),
                "sha256": sha256_of(HOSTS_PATH),
            }
        except Exception as e:
            hosts_entry = {"original": HOSTS_PATH, "error": str(e)}

    total = sum(e.get("size", 0) for e in entries)
    errors = [e for e in entries if "error" in e]

    manifest = {
        "time": stamp,
        "note": note,
        "source_dir": CLASHMI_DATA_DIR,
        "core_path": core_path,
        "file_count": len(entries),
        "total_bytes": total,
        "hosts": hosts_entry,
        "files": sorted(entries, key=lambda e: e["rel"]),
    }
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    say()
    say("=" * 68)
    say(" 备份完成")
    say("=" * 68)
    say("  文件数   : {}".format(len(entries)))
    say("  总大小   : {:.2f} MB".format(total / 1024 / 1024))
    say("  hosts    : {}".format("已备份" if hosts_entry and "error" not in hosts_entry else "未备份"))
    say("  内核入口 : {}".format(core_path or "(未读到 service.json)"))
    say("  位置     : {}".format(out_dir))
    if errors:
        say()
        say("[!] 有 {} 个文件复制失败:".format(len(errors)))
        for e in errors[:10]:
            say("    {} -> {}".format(e["rel"], e["error"]))
        return 4
    say()
    say("关键文件校验值（与原文件一致即备份无损）:")
    for e in manifest["files"]:
        if e["rel"].lower().endswith((".yaml", ".yml", ".json")):
            say("  {}  {}  {}".format(e["sha256"][:16], "{:>9}".format(e["size"]), e["rel"]))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        say()
        say("已中断。已复制的部分保留在目标目录，可安全删除。")
        sys.exit(130)
