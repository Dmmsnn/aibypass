@echo off
setlocal
chcp 65001 >nul
title ClashMi tunnels - apply

rem 优先用带 psutil + PyYAML 的隔离环境，其次裸 Python
set "PY=C:\Users\Administrator\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" "%~dp0apply-tunnel.py" %*
set "RC=%ERRORLEVEL%"

echo.
echo ---------------------------------------------------------------
if "%RC%"=="0" (
  echo Done. Exit code 0.
) else (
  echo Stopped. Exit code %RC%  - no changes were made, or see message above.
)
echo Reminder: if hosts needed writing, run this as Administrator.
echo ---------------------------------------------------------------
pause
endlocal
