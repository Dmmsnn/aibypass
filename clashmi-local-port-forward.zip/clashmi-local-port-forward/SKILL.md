---
name: clashmi-local-port-forward
description: 在 Windows 的 ClashMi / mihomo 上用 tunnels 把本机端口原样转发到目标域名或 IP（L4 端口转发，不改 SNI / Host / 证书），并验证是否真的生效。触发：ClashMi 转发、本地端口转发、把域名代理到本地、代理到本地、tunnels、mihomo 转发、原样转发、配置改了不生效、该改哪个配置文件、service-config、8443。
agent_created: true
---

# ClashMi 本地端口转发（tunnels）

**要什么**：访问本机端口 → 请求原样（SNI / Host / 证书都不改）送到真实目标。
**只有 `tunnels` 能做**（mihomo 原生 L4 转发）。`rules` 只决定走哪个出口、不能改目标；`hosts` 只改解析、不建监听 —— 别往这两处撞。

前置：内核是 mihomo (Clash.Meta)，`GET /version` 里 `meta: true`（实测 1.19.10 可用；原版 Clash 不支持）。

---

## 一、最短路径（照抄）

```bash
cd <脚本目录>                    # scripts/ ，或工作区 clashmi-tunnel/

run-backup-full.cmd              # 0) 备份（改配置前必做）

python scripts/apply-tunnel.py --domain <域名> --ip <实测IP> \
       --local-port 8443 --target-port 443 --proxy '一分机场' \
       --no-hosts --assume-closed --yes      # 1) 写入；先加 --dry-run 看一遍

# 2) 让内核重载：界面「断开→重连」/ 重启 ClashMi / PUT /configs
# 3) 复查配置文件里那段还在（ClashMi 退出可能回写旧配置，把改动顶掉）
run-verify.cmd                   # 4) 验证（一条命令）
```

写入的是一个**带标记的块**，重复运行原地替换、不叠加：

```yaml
# >>> clashmi-tunnel managed block >>>
tunnels:
  - network: [tcp]
    address: 127.0.0.1:8443   # 本机监听，端口任意
    target: 1.2.3.4:443       # 必须写 IP（铁律 1）
    proxy: '一分机场'          # 出口，也可 DIRECT
# <<< clashmi-tunnel managed block <<<
```

参数：`--dry-run` / `--no-hosts` / `--yes` / `--assume-closed`（跳过运行检测）/ `--service-config <path>`（手工指定实例）。

**怎么访问**：`target` 的端口决定本地用什么协议 —— 目标 `:80` 用 `http://127.0.0.1:8443/`，目标 `:443` 用 `https://`。
本地监听端口随便选（避开 7890/9090）。细节和两个坎见 §四。

---

## 二、三条铁律

**1. `target` 必须写 IP，不能写域名。** 想用域名访问本机端口，得靠 hosts 把该域名指到 `127.0.0.1`；而 ClashMi 强制 `use-system-hosts: true`（内核会读 Windows hosts）→ `target` 写域名会解析回 `127.0.0.1`，**连自己死循环**。

**2. IP 必须实测，TCP 通 ≠ 能用。** 实测同一域名两个 IP：一个带 SNI 握手成功，另一个握手超时。写 `target` 前先做一次**带真实 SNI 的 TLS 探测**（`verify-tunnel.py` 第 5 项就是这个做法）。

**3. 改完必须重载 + 复查。** 写文件 ≠ 生效；且 ClashMi 退出时可能把内存里的旧配置回写。顺序：写入 → 重载 → 复查那段还在 → 验证。

---

## 三、找不到实例？读进程参数，别猜目录

本机常同时有两套 ClashMi：

| | 程序目录 | 数据目录 | |
|---|---|---|---|
| A | `C:\Program Files\Clash Mi`（带空格） | `%APPDATA%\clashmi\clashmi` | 旧安装 |
| B | `C:\Program Files\ClashMi` | `C:\Program Files\ClashMi\portable` | **portable，实际在用** |

唯一可靠判定：读运行进程命令行里的 `--service-config=...` → 该文件中的 `core_path` → 那才是内核真正加载的 YAML。
靠 `%APPDATA%` 或目录名猜的典型症状：配置写对了、YAML 也校验通过、就是完全没反应。

---

## 四、访问形式：先按协议选，再过两个坎

| 目标 | `target` | 本地访问 | 能直接跑通吗 |
|---|---|---|---|
| HTTP | `<IP>:80` | `http://127.0.0.1:8443/<path>` | ✅ 明文，**没有证书、没有 SNI** |
| HTTPS | `<IP>:443` | `https://127.0.0.1:8443/<path>` | ⚠️ 握手通，但**证书名校验失败**（证书属域名） |

### 坎 1 — HTTPS 的证书名校验（HTTP 目标没有这层）

tunnel 只做 L4，不改 SNI / Host / 证书，所以客户端"说的名字"必须是真实域名。

| 访问姿势 | 写法 | 校验 |
|---|---|---|
| 零告警 | `curl --noproxy '*' --resolve 域名:端口:127.0.0.1 https://域名:端口/` | ✅ |
| 本地 IP + 跳过 | `curl --noproxy '*' -k https://127.0.0.1:端口/` | ✅（人为跳过） |
| 本地 IP + 严格 | `curl --noproxy '*' https://127.0.0.1:端口/` | ❌ `SEC_E_WRONG_PRINCIPAL` |

先探一次目标是否依赖 SNI：以 `SNI=域名` / `SNI=IP` / 不发 SNI 各探一次 ——
三者都返回同一张证书 = 单站点部署（怎么访问都行，只需处理客户端校验）；只有 `SNI=域名` 才对 = 必须带域名。

浏览器用域名访问还要 hosts + 把域名加进代理绕过列表（否则 `CONNECT 域名:端口` 被丢给节点，走不到本机 tunnel）；代码客户端用 `verify=False` / `-k`。
想让局域网其它设备也能访问：`address` 改 `0.0.0.0:<port>` 并放行防火墙。

### 坎 2 — Host 头路由（**两种协议都躲不开**）

tunnel 是四层转发，**不改写 `Host`**，"入口用什么名字访问，目标站就看到什么 Host"。目标 nginx 若按 `server_name` 分虚拟主机：

| 访问 | 发出的 Host | 结果 |
|---|---|---|
| 直连 `http://<目标IP>/path` | `<目标IP>` | 命中正确 vhost |
| 隧道 `http://127.0.0.1:8443/path` | `127.0.0.1:8443` | **落到默认 vhost**（典型 404 或另一个应用） |
| 隧道 + 手动 `Host: <目标IP>` | `<目标IP>` | 与直连**逐字节一致** ✅ |

定位手法：固定路径，只改 Host 逐项对照。旁证：`Server:` 头可能不同（不同 server 块配置不同）；不合法 Host 常被 `return 444` 直接**重置连接**（报 ConnectionResetError 而非 4xx）。target 是 `:80` 时 `verify-tunnel.py` 会自动做一次 `Host=<目标IP>` 对照并报差异，不用手动铺矩阵。
**反直觉但实测存在**：目标可能**恰恰拒绝** `Host=<目标IP>`（403 / 4xx）。此时默认的 `127.0.0.1:8443` 反而是能进站的那个 Host，别急着去"修" Host。

**推论**：`address` 用 `127.0.0.1` 时，浏览器地址栏必然把 Host 发成 `127.0.0.1:8443`，**这一点改不了**（L4 能力之外）。
命令行客户端可手动置 Host；要让浏览器也一致，只能在前面挡一层能改写 Host 的反向代理 —— 评估需求时先把这条讲清楚。
**现成工具**：`scripts/host-rewrite-proxy.py`。起一个本机入口端口，强制 `Host: <指定值>` 再转给 tunnel，其余原样透传：
`python host-rewrite-proxy.py --listen 127.0.0.1:8080 --upstream 127.0.0.1:8443 --host-header <Host值>`。
纯 HTTP（含 chunked），不支持 WS/HTTPS。**纯 curl 验证时注意 UA**：有的站点按 UA 分级（非浏览器 UA 收 403、浏览器 UA 收应用页），漏了 UA 会把正常结果当故障。

---

## 五、不通时往下走（按顺序）

| # | 检查 | 不通过说明 |
|---|---|---|
| 1 | `127.0.0.1:9090` 可连 + `/version` | 内核没跑，或实例找错了 |
| 2 | 本机端口 LISTENING 且属主是 ClashMi | 内核**没接受** tunnels → 回查实例 / 重载 |
| 3 | 入口 YAML 的 tunnels **非空**（解析后判，不靠字符串匹配） | 配置没在。内核会把空配置写成 `tunnels: []`，纯字符串匹配会假阳性 |
| 4 | 对本机端口发真实请求（脚本按配置里该条 tunnel 的 target 端口自动选：`:80` 明文 HTTP，其余带真实 SNI 的 TLS） | 1、2 过而这里不过 → 问题在**出站节点**，换 proxy |

内核直接拒绝字段的话，`service_core.log` 里能搜到 yaml / tunnels 报错。

**测本机端口时 curl 必须加 `--noproxy '*'`。** shell 常被注入 `http_proxy` / `https_proxy`（**端口每次会话都变**，先 `env | grep -i proxy` 看当前值）。
不加的话 `https://域名:8443` 会变成把 `CONNECT 域名:8443` 交给代理 → 代理去连**公网的 8443** → 15 秒超时，看着像 tunnel 坏了，其实是测法错了。Python 的 `socket` / `ssl` 直连不受代理变量影响，是更可靠的判据；但 `urllib.request` / `requests` **仍会读**这两个变量 —— 实测把 `http://127.0.0.1:9090/version` 交给代理会返回 **502**（看着像内核崩了），要用它们必须显式 `ProxyHandler({})`。

---

## 六、已知限制 / 还原

- **订阅更新会覆盖。** `profiles.json` 的 `update_interval` 非 null 时，订阅刷新会用新文件顶掉 tunnels 段（为 `null` 说明已关自动更新）。重跑一次 `apply-tunnel.py` 即可。
- **系统代理模式下浏览器可能绕过 hosts 映射。** `CONNECT 域名:端口` 按主机名字符串匹配绕过列表，命中不了。用 TUN 模式并关系统代理、或把域名加进绕过列表、或直接访问 `https://127.0.0.1:<port>`。
- **还原**：`scripts/restore-tunnel.py` 备份带 SHA256 清单，还原前先存 `pre-restore-*` 快照（还原本身也可逆）。
  `--list` 列备份 / `--backup <时间戳>` 精确还原（多实例推荐）/ `--for <路径子串>` / `--latest`（多实例慎用，只看时间戳可能还原错实例）/ `--force`。
  manifest 有单文件（`original`）与全量快照（`rel`）两种格式；后者**已被脚本主动拒绝**走单文件还原，避免按相对路径误覆盖。

---

## 环境事实（本机已验证，2026-09）

- 内核：mihomo **1.19.10**（`meta: true`，支持 `tunnels`）
- 在用实例（B）数据目录：`C:\Program Files\ClashMi\portable`，portable 模式**可写、无需提权**
- REST API：`127.0.0.1:9090`，secret 在 `service.json` 的 `secret` 字段
- 端口：`mixed-port: 7890`、`external-controller: 127.0.0.1:9090`
- 脚本需 `psutil` + `PyYAML`，优先用 venv：
  `C:\Users\Administrator\.workbuddy\binaries\python\envs\default\Scripts\python.exe`
